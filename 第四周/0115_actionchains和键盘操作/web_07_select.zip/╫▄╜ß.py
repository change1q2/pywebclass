#!/usr/bin/env python3
#-*- coding:utf-8 -*-
# email: wagyu2016@163.com
# wechat: shoubian01
# author: 王雨泽

"""验证码
1，数字和字母， OCR 技术
2，极验， python
3，12306， 1， 找开发。
4，人工打码，收费，


"""