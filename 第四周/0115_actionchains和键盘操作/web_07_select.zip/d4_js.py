"""
js = JavaScript,
在网页当中，负责动态展示部分。 编程语言，

HTML: 标记语言，静态展示。

WebAssembly, python


"""